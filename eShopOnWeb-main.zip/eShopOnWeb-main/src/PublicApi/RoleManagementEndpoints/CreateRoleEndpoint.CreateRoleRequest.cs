﻿namespace Microsoft.eShopWeb.PublicApi.RoleManagementEndpoints;

public class CreateRoleRequest : BaseRequest
{
    public string Name { get; set; }
}
