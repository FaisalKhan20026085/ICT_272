﻿namespace Microsoft.eShopWeb.Web.Configuration;

public class BaseUrlConfiguration
{
    public const string CONFIG_NAME = "baseUrls";

    public string ApiBase { get; set; } = string.Empty;
}
