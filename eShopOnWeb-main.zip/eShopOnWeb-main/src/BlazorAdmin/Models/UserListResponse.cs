﻿using System.Collections.Generic;

namespace BlazorAdmin.Models;

public class UserListResponse
{
    public List<User> Users { get; set; } = [];
}
