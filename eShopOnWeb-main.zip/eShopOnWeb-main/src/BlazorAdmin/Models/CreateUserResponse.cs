﻿namespace BlazorAdmin.Models;

public class CreateUserResponse
{
    public string UserId { get; set; }
}
