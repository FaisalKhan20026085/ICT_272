﻿using System.Collections.Generic;

namespace BlazorAdmin.Models;

public class GetUserRolesResponse
{
    public List<string> Roles { get; set; }

    
}
