﻿namespace BlazorAdmin.Models;

public record UserForMembership (string UserName, string Id);
