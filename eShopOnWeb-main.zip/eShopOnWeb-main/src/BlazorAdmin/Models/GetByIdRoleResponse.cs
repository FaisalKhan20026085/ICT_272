﻿using Microsoft.AspNetCore.Identity;

namespace BlazorAdmin.Models;

public class GetByIdRoleResponse
{
    public IdentityRole Role { get; set; }
}
