---
title: "Architecture Decision Records"
nav_order: 1
layout: adr-index
---

These are the decisions that have been made for eShopOnWeb.