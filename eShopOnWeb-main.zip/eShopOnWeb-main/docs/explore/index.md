---
title: Explore
---

While the associated e-book covers the general principles and patterns, the specific implementation details for much of the code is included in the source code and explained further here.
