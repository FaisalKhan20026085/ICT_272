---
title: Request for ADRs
decisioner: Steve "Ardalis" Smith
status: Active
date: 2025-04-24
---

We will implement Architecture Decision Records in the eShopOnWeb documentation.

For now, it is in "/decisions".